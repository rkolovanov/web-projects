jQuery('document').ready(function(){
});